-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: bar
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `bebida`
--

LOCK TABLES `bebida` WRITE;
/*!40000 ALTER TABLE `bebida` DISABLE KEYS */;
INSERT INTO `bebida` VALUES (1001,'Tequila',60.99,'Tequila Jose Cuervo Especial',1),(1002,'Whisky',60.99,'Whisky Johnnie Walker, Red Label',50),(1003,'Ron',60.99,'Ron Bacardi, Carta Blanca',40),(1004,'Brandy',60.99,'Brandy Don Pedro',23),(1005,'Vodka',60.99,'Vodka Absolut',14),(1006,'Cerveza',40.99,'Nacional',47),(1007,'Cerveza',50.99,'Importada',100),(1008,'Perla Negra',70.99,'Jagermeister, Whisky, Bebida Energizante',80),(1009,'Paloma',50.99,'Tequila(blanco), Limon, Sal, Refresco de toronja',50),(1010,'Vampiro',60,'Tequila, Sangrita, Sal, Limon, Refresco de toronja',30),(1011,'Cuba',50.99,'Refresco(Normal), Ron',101),(1012,'Vodka con Jugo',50.99,'Vodka, Jugo(Piña, Arandano, Naranja',11),(1013,'Shots',100.99,'Ronda de 4 Caballitos (Cualquier Licor)',10),(1014,'Agua',20.99,'Agua natural',95),(1015,'Agua de Sabor',30,'Agua de Sabor(Limon, Jamaica, Piña)',81),(1016,'Refresco',30.99,'Cualquier tipo de Refresco',100);
/*!40000 ALTER TABLE `bebida` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-13 23:22:14
